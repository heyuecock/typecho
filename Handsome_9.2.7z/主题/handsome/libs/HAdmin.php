<?php

if (!defined('__TYPECHO_ROOT_DIR__')) {
	exit;
}
require_once("Settings.php");

class Hadmin
{
	public static function SettingsWelcome()
	{
		Utils::initGlobalDefine(true);
		echo Settings::useIntro() . Settings::checkupdatejs(). Settings::styleoutput();
		echo Settings::initAll();
		echo '<script src="' . STATIC_PATH . '/libs/jquery/jquery.min.js"></script>';
		echo '<script src="' . STATIC_PATH . '/libs/mdui/mdui.min.js"></script>';
		echo '<script src="' . STATIC_PATH . '/js/admin/admin.min.js"></script>';
	}
	


}
