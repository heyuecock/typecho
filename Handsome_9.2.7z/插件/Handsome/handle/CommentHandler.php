<?php

/**
 * 与评论相关的钩子拦截处理
 */
class Handsome_Comment_Handler{

}
