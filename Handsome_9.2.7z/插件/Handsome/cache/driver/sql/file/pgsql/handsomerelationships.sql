CREATE TABLE "%dbname%"
(  "coid" INT NOT NULL DEFAULT '0',
    "tid" INT NOT NULL DEFAULT '0',
    PRIMARY KEY ("coid","tid")
);